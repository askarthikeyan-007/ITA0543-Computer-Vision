import cv2
import os
import sys
import numpy as np

# Add root directory to python path for sample utility
current_dir = os.path.dirname(os.path.abspath(__file__))
root_dir = os.path.dirname(current_dir)
sys.path.append(root_dir)

# Ensure sample files exist
try:
    import sample_generator
    sample_generator.ensure_samples_exist(root_dir)
except Exception as e:
    print(f"Warning: Could not check or generate sample inputs: {e}")

# Read the sample crowd face image (composite group photo)
input_path = os.path.join(root_dir, "sample_crowd.jpg")
img = cv2.imread(input_path)
if img is None:
    print(f"Error: Could not read input image from {input_path}")
    sys.exit(1)

# Load the built-in Haar Cascade classifier for face detection
face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
if face_cascade.empty():
    print("Error: Could not load face Haar Cascade classifier.")
    sys.exit(1)

# Convert to grayscale
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

# Detect faces in the image
# Adjust parameters slightly for the composed Lena grids
faces = face_cascade.detectMultiScale(
    gray,
    scaleFactor=1.1,
    minNeighbors=5,
    minSize=(30, 30)
)

output_img = img.copy()

# Count the detected faces
face_count = len(faces)

# Draw rectangles around the detected faces and draw index
for idx, (x, y, w, h) in enumerate(faces):
    cv2.rectangle(output_img, (x, y), (x + w, y + h), (0, 255, 0), 3)
    cv2.putText(output_img, f"Face #{idx+1}", (x, y - 10), 
                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1, cv2.LINE_AA)

# Draw the face count text banner on top
banner_height = 40
banner = np.zeros((banner_height, output_img.shape[1], 3), dtype=np.uint8)
# Concatenate header banner at the top
cv2.putText(banner, f"Total Faces Counted: {face_count}", (20, 26), 
            cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2, cv2.LINE_AA)
output_img = np.vstack((banner, output_img))

print(f"Successfully counted: {face_count} face(s).")

# Save the output image
output_path = os.path.join(current_dir, "output.jpg")
cv2.imwrite(output_path, output_img)
print(f"Face count result saved to: {output_path}")

# Display original and counted images
try:
    cv2.imshow("Original Crowd Image", img)
    cv2.imshow("Face Counting Result", output_img)
    print("Press 'q' or 'Esc' in any window to exit.")
    while True:
        key = cv2.waitKey(30) & 0xFF
        if key == ord('q') or key == 27:
            break
    cv2.destroyAllWindows()
except Exception as e:
    print(f"Display window skipped: {e}. Output saved to file successfully.")
