import cv2
import numpy as np
import os
import sys

# Add root directory to python path for sample utility
current_dir = os.path.dirname(os.path.abspath(__file__))
root_dir = os.path.dirname(current_dir)
sys.path.append(root_dir)

# Ensure sample files exist
try:
    import sample_generator
    sample_generator.ensure_samples_exist(root_dir)
except Exception as e:
    print(f"Warning: Could not check or generate sample inputs: {e}")

# Read the sample input video
video_path = os.path.join(root_dir, "sample_video.mp4")
cap = cv2.VideoCapture(video_path)
if not cap.isOpened():
    print(f"Error: Could not open video from {video_path}")
    sys.exit(1)

# Get video properties
width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
fps = cap.get(cv2.CAP_PROP_FPS)
if fps <= 0:
    fps = 30.0

# Prepare video writer for output
output_video_path = os.path.join(current_dir, "output.mp4")
fourcc = cv2.VideoWriter_fourcc(*'mp4v')
out = cv2.VideoWriter(output_video_path, fourcc, fps, (width, height))

# Check OCR libraries availability
has_pytesseract = False
try:
    import pytesseract
    has_pytesseract = True
    print("OCR Engine: pytesseract is available.")
except ImportError:
    pass

has_easyocr = False
try:
    import easyocr
    reader = easyocr.Reader(['en'], gpu=False)
    has_easyocr = True
    print("OCR Engine: easyocr is available.")
except ImportError:
    pass

frame_count = 0
processed_frames = []

while True:
    ret, frame = cap.read()
    if not ret:
        break
    
    output_frame = frame.copy()
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    
    # Text Localization Pipeline:
    # 1. Compute morphological gradient to highlight edges of characters
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
    grad = cv2.morphologyEx(gray, cv2.MORPH_GRADIENT, kernel)
    
    # 2. Otsu thresholding to binarize
    _, thresh = cv2.threshold(grad, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    
    # 3. Horizontal closing to group letters/words together into text line blocks
    kernel_close = cv2.getStructuringElement(cv2.MORPH_RECT, (15, 3))
    closed = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel_close)
    
    # 4. Find contours of candidate text regions
    contours, _ = cv2.findContours(closed, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    
    text_regions_found = 0
    for contour in contours:
        x, y, w, h = cv2.boundingRect(contour)
        
        # Filter regions by size and aspect ratio typical for text labels (width > height, not too small or huge)
        aspect_ratio = float(w) / h
        if w > 25 and h > 8 and h < 50 and aspect_ratio > 1.2 and aspect_ratio < 10:
            text_regions_found += 1
            cv2.rectangle(output_frame, (x - 2, y - 2), (x + w + 2, y + h + 2), (0, 255, 0), 2)
            
            # Crop the candidate text box for OCR processing
            text_crop = frame[y:y+h, x:x+w]
            
            # 5. Perform OCR if library is available
            extracted_text = ""
            if has_pytesseract:
                try:
                    # Optional: convert to gray/threshold for better OCR
                    crop_gray = cv2.cvtColor(text_crop, cv2.COLOR_BGR2GRAY)
                    extracted_text = pytesseract.image_to_string(crop_gray, config='--psm 7').strip()
                except Exception:
                    pass
            elif has_easyocr:
                try:
                    results = reader.readtext(text_crop)
                    if len(results) > 0:
                        extracted_text = results[0][1].strip()
                except Exception:
                    pass
            
            # Overlay detected text above bounding box if found
            if extracted_text:
                cv2.putText(output_frame, extracted_text, (x, y - 6), 
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1, cv2.LINE_AA)
                if frame_count % 30 == 0:  # Print text sample occasionally to console
                    print(f"[Frame {frame_count}] OCR Text: '{extracted_text}'")

    out.write(output_frame)
    processed_frames.append(output_frame)
    frame_count += 1

cap.release()
out.release()
print(f"Processed video written to: {output_video_path}")

# Print warning and instructions if no OCR engines are installed
if not has_pytesseract and not has_easyocr:
    print("\n--- OCR Integration Instructions ---")
    print("No OCR engine (pytesseract or easyocr) was detected. The script completed text block localization")
    print("and highlighted text candidates (such as static and moving overlay labels) with green rectangles.")
    print("To enable full text character recognition, please install pytesseract or easyocr:")
    print("  pip install pytesseract")
    print("or")
    print("  pip install easyocr")
    print("For Tesseract, also make sure the Tesseract binary is installed and added to your system PATH.")
    print("------------------------------------\n")

# Display the processed video
try:
    print("Playing video with localized text regions... (Press 'q' to exit)")
    for f in processed_frames:
        cv2.imshow("Text Localization & OCR Extraction", f)
        if cv2.waitKey(33) & 0xFF == ord('q'):
            break
    cv2.destroyAllWindows()
except Exception as e:
    print(f"Display window skipped: {e}. Output video saved successfully.")
