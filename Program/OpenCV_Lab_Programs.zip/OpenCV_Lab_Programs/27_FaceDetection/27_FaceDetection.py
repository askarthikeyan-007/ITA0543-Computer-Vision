import cv2
import os
import sys

# Add root directory to python path for sample utility
current_dir = os.path.dirname(os.path.abspath(__file__))
root_dir = os.path.dirname(current_dir)
sys.path.append(root_dir)

# Ensure sample files exist
try:
    import sample_generator
    sample_generator.ensure_samples_exist(root_dir)
except Exception as e:
    print(f"Warning: Could not check or generate sample inputs: {e}")

# Read the sample face image (Lena)
input_path = os.path.join(root_dir, "sample_face.jpg")
img = cv2.imread(input_path)
if img is None:
    print(f"Error: Could not read input image from {input_path}")
    sys.exit(1)

# Load the built-in Haar Cascade classifier for face detection
cascade_path = cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
face_cascade = cv2.CascadeClassifier(cascade_path)

if face_cascade.empty():
    print(f"Error: Haar Cascade XML file could not be loaded from {cascade_path}")
    sys.exit(1)

# Convert to grayscale (Haar classifier works on gray images)
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

# Detect faces in the image
faces = face_cascade.detectMultiScale(
    gray,
    scaleFactor=1.1,
    minNeighbors=5,
    minSize=(30, 30)
)

# Draw rectangles around the detected faces
output_img = img.copy()
for (x, y, w, h) in faces:
    cv2.rectangle(output_img, (x, y), (x + w, y + h), (255, 0, 0), 2)
    cv2.putText(output_img, "Face", (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 0, 0), 2)

print(f"Detected {len(faces)} face(s).")

# Save the output image
output_path = os.path.join(current_dir, "output.jpg")
cv2.imwrite(output_path, output_img)
print(f"Face detection result saved to: {output_path}")

# Display original and face detected images
try:
    cv2.imshow("Original Image", img)
    cv2.imshow("Detected Faces", output_img)
    print("Press 'q' or 'Esc' in any window to exit, or close the windows to quit.")
    while True:
        key = cv2.waitKey(30) & 0xFF
        if key == ord('q') or key == 27:
            break
        # Check if any window was closed using the [X] button
        if cv2.getWindowProperty("Original Image", cv2.WND_PROP_VISIBLE) < 1 or \
           cv2.getWindowProperty("Detected Faces", cv2.WND_PROP_VISIBLE) < 1:
            break
    cv2.destroyAllWindows()
except Exception as e:
    print(f"Display window skipped: {e}. Output saved to file successfully.")
