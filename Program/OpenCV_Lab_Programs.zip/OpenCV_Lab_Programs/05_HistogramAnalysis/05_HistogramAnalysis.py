import cv2
import os
import sys
import matplotlib.pyplot as plt

# Add root directory to python path for sample utility
current_dir = os.path.dirname(os.path.abspath(__file__))
root_dir = os.path.dirname(current_dir)
sys.path.append(root_dir)

# Ensure sample files exist
try:
    import sample_generator
    sample_generator.ensure_samples_exist(root_dir)
except Exception as e:
    print(f"Warning: Could not check or generate sample inputs: {e}")

# Read the sample input image
input_path = os.path.join(root_dir, "sample_input.jpg")
img = cv2.imread(input_path)
if img is None:
    print(f"Error: Could not read input image from {input_path}")
    sys.exit(1)

# Compute and plot histogram for RGB channels
plot_path = os.path.join(current_dir, "histogram_plot.png")
try:
    # Attempt to open interactive display figure
    plt.figure(figsize=(10, 5))
except Exception:
    # If it fails (e.g. headless environment), fallback to Agg backend
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.figure(figsize=(10, 5))

try:
    plt.subplot(1, 2, 1)
    colors = ('b', 'g', 'r')
    for i, col in enumerate(colors):
        hist = cv2.calcHist([img], [i], None, [256], [0, 256])
        plt.plot(hist, color=col, label=f"Channel {col.upper()}")
        plt.xlim([0, 256])
    plt.title("Color Histogram")
    plt.xlabel("Bins")
    plt.ylabel("Number of Pixels")
    plt.legend()

    # Compute and plot histogram for grayscale representation
    plt.subplot(1, 2, 2)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    hist_gray = cv2.calcHist([gray], [0], None, [256], [0, 256])
    plt.plot(hist_gray, color='black')
    plt.xlim([0, 256])
    plt.title("Grayscale Histogram")
    plt.xlabel("Bins")
    plt.ylabel("Number of Pixels")

    plt.tight_layout()

    # Save the plot
    plt.savefig(plot_path)
    print(f"Histogram analysis plot saved to: {plot_path}")

    # Display the plot window
    try:
        plt.show()
    except Exception as e:
        print(f"Display window skipped: {e}. Plot saved to file successfully.")
except Exception as e:
    print(f"Error during histogram analysis plotting: {e}")

