import cv2
import os
import sys

# Add root directory to python path for sample utility
current_dir = os.path.dirname(os.path.abspath(__file__))
root_dir = os.path.dirname(current_dir)
sys.path.append(root_dir)

# Ensure sample files exist
try:
    import sample_generator
    sample_generator.ensure_samples_exist(root_dir)
except Exception as e:
    print(f"Warning: Could not check or generate sample inputs: {e}")

# Read the sample input image
input_path = os.path.join(root_dir, "sample_input.jpg")
img = cv2.imread(input_path)
if img is None:
    print(f"Error: Could not read input image from {input_path}")
    sys.exit(1)

# Copy image for drawing
canvas = img.copy()

# 1. Draw static rectangles for demonstration
# Parameters: image, start_point, end_point, color (BGR), thickness (-1 for filled)
cv2.rectangle(canvas, (30, 100), (180, 220), (0, 0, 255), 3) # Outline Red
cv2.rectangle(canvas, (210, 100), (360, 220), (0, 255, 0), -1) # Filled Green
cv2.rectangle(canvas, (390, 100), (540, 220), (255, 255, 0), 5) # Yellow thick outline
cv2.putText(canvas, "Static Rectangles Demo", (30, 260), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)

# Save the pre-drawn static result
static_output_path = os.path.join(current_dir, "output.jpg")
cv2.imwrite(static_output_path, canvas)
print(f"Static rectangle image saved to: {static_output_path}")

# 2. Interactive Drag-to-Draw variables
drawing = False
ix, iy = -1, -1

# Mouse callback function
def draw_rect_callback(event, x, y, flags, param):
    global ix, iy, drawing, canvas

    if event == cv2.EVENT_LBUTTONDOWN:
        drawing = True
        ix, iy = x, y

    elif event == cv2.EVENT_MOUSEMOVE:
        if drawing:
            # Show a preview of the rectangle dynamically by copying the canvas state
            temp_canvas = canvas.copy()
            cv2.rectangle(temp_canvas, (ix, iy), (x, y), (0, 255, 255), 2)
            cv2.imshow("Interactive Rectangle Drawing", temp_canvas)

    elif event == cv2.EVENT_LBUTTONUP:
        drawing = False
        # Draw the permanent yellow rectangle on mouse release
        cv2.rectangle(canvas, (ix, iy), (x, y), (0, 255, 255), 2)
        cv2.imshow("Interactive Rectangle Drawing", canvas)
        # Save the updated drawing to disk
        cv2.imwrite(static_output_path, canvas)

# Run interactive window
try:
    cv2.namedWindow("Interactive Rectangle Drawing")
    cv2.setMouseCallback("Interactive Rectangle Drawing", draw_rect_callback)
    
    cv2.imshow("Interactive Rectangle Drawing", canvas)
    print("INSTRUCTIONS:")
    print("1. Click and drag the left mouse button inside the window to draw custom yellow rectangles.")
    print("2. The drawing will be saved to disk automatically upon button release.")
    print("3. Press 'q' or 'Esc' to exit.")
    
    while True:
        key = cv2.waitKey(30) & 0xFF
        if key == ord('q') or key == 27:
            break
            
    cv2.destroyAllWindows()
except Exception as e:
    print(f"Interactive window skipped: {e}. Pre-drawn static output saved successfully.")
