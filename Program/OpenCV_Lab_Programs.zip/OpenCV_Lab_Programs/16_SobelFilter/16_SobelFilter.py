import cv2
import numpy as np
import os
import sys

# Add root directory to python path for sample utility
current_dir = os.path.dirname(os.path.abspath(__file__))
root_dir = os.path.dirname(current_dir)
sys.path.append(root_dir)

# Ensure sample files exist
try:
    import sample_generator
    sample_generator.ensure_samples_exist(root_dir)
except Exception as e:
    print(f"Warning: Could not check or generate sample inputs: {e}")

# Read the sample input image
input_path = os.path.join(root_dir, "sample_input.jpg")
img = cv2.imread(input_path)
if img is None:
    print(f"Error: Could not read input image from {input_path}")
    sys.exit(1)

# Convert to grayscale
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

# Calculate Sobel gradient along X axis
sobel_x = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
# Calculate Sobel gradient along Y axis
sobel_y = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)

# Get absolute values and convert back to 8-bit unsigned integers
abs_sobel_x = np.uint8(np.absolute(sobel_x))
abs_sobel_y = np.uint8(np.absolute(sobel_y))

# Combine the two gradients (Sobel Magnitude approximation)
sobel_combined = cv2.addWeighted(abs_sobel_x, 0.5, abs_sobel_y, 0.5, 0)

# Save the output image
output_path = os.path.join(current_dir, "output.jpg")
cv2.imwrite(output_path, sobel_combined)
print(f"Sobel filtered image saved to: {output_path}")

# Display Sobel X, Sobel Y and Sobel Combined
try:
    cv2.imshow("Sobel X", abs_sobel_x)
    cv2.imshow("Sobel Y", abs_sobel_y)
    cv2.imshow("Sobel Combined Magnitude", sobel_combined)
    print("Press 'q' or 'Esc' in any window to exit.")
    while True:
        key = cv2.waitKey(30) & 0xFF
        if key == ord('q') or key == 27:
            break
    cv2.destroyAllWindows()
except Exception as e:
    print(f"Display window skipped: {e}. Output saved to file successfully.")
