import cv2
import numpy as np
import os
import sys

# Add root directory to python path for sample utility
current_dir = os.path.dirname(os.path.abspath(__file__))
root_dir = os.path.dirname(current_dir)
sys.path.append(root_dir)

# Ensure sample files exist
try:
    import sample_generator
    sample_generator.ensure_samples_exist(root_dir)
except Exception as e:
    print(f"Warning: Could not check or generate sample inputs: {e}")

# Read the sample input image
input_path = os.path.join(root_dir, "sample_input.jpg")
img = cv2.imread(input_path)
if img is None:
    print(f"Error: Could not read input image from {input_path}")
    sys.exit(1)

# Convert to grayscale and binary threshold
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
_, binary = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

# Add synthetic noise (black holes inside the white foreground)
# To target foreground, we only put black pixels where binary is 255
noisy_binary = binary.copy()
h, w = noisy_binary.shape
noise_density = 0.05 # 5% noise dots inside foreground
fg_coords = np.argwhere(binary == 255)
num_noise_pixels = int(noise_density * len(fg_coords))
if num_noise_pixels > 0:
    indices = np.random.choice(len(fg_coords), num_noise_pixels, replace=False)
    for idx in indices:
        y_rand, x_rand = fg_coords[idx]
        noisy_binary[y_rand, x_rand] = 0

# Define structuring element (5x5 rectangular kernel)
kernel = np.ones((5, 5), np.uint8)

# Perform Morphological Closing (closes small dark holes inside foreground)
closed_img = cv2.morphologyEx(noisy_binary, cv2.MORPH_CLOSE, kernel)

# Save the output image
output_path = os.path.join(current_dir, "output.jpg")
cv2.imwrite(output_path, closed_img)
print(f"Closed binary image saved to: {output_path}")

# Display noisy binary and closed images
try:
    cv2.imshow("Noisy Binary Image (Holes Added)", noisy_binary)
    cv2.imshow("Morphological Closing (Holes Closed)", closed_img)
    print("Press 'q' or 'Esc' in any window to exit.")
    while True:
        key = cv2.waitKey(30) & 0xFF
        if key == ord('q') or key == 27:
            break
    cv2.destroyAllWindows()
except Exception as e:
    print(f"Display window skipped: {e}. Output saved to file successfully.")
