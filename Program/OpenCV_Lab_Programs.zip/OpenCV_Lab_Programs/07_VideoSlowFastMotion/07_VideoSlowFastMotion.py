import cv2
import os
import sys

# Add root directory to python path for sample utility
current_dir = os.path.dirname(os.path.abspath(__file__))
root_dir = os.path.dirname(current_dir)
sys.path.append(root_dir)

# Ensure sample files exist
try:
    import sample_generator
    sample_generator.ensure_samples_exist(root_dir)
except Exception as e:
    print(f"Warning: Could not check or generate sample inputs: {e}")

# Read the sample input video
video_path = os.path.join(root_dir, "sample_video.mp4")
cap = cv2.VideoCapture(video_path)
if not cap.isOpened():
    print(f"Error: Could not open video from {video_path}")
    sys.exit(1)

# Get video properties
width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
fps = cap.get(cv2.CAP_PROP_FPS)
if fps <= 0:
    fps = 30.0

frames = []
while True:
    ret, frame = cap.read()
    if not ret:
        break
    frames.append(frame)
cap.release()

if len(frames) == 0:
    print("Error: No frames read from video.")
    sys.exit(1)

# Generate Slow Motion (Half speed - write at 15 FPS)
slow_path = os.path.join(current_dir, "output_slow.mp4")
fourcc = cv2.VideoWriter_fourcc(*'mp4v')
out_slow = cv2.VideoWriter(slow_path, fourcc, fps / 2, (width, height))
for frame in frames:
    out_slow.write(frame)
out_slow.release()
print(f"Slow motion video saved to: {slow_path}")

# Generate Fast Motion (Double speed - write at 60 FPS or write every 2nd frame at 30 FPS)
fast_path = os.path.join(current_dir, "output_fast.mp4")
out_fast = cv2.VideoWriter(fast_path, fourcc, fps, (width, height))
# Write every second frame to double the motion speed at normal frame rate
for i in range(0, len(frames), 2):
    out_fast.write(frames[i])
out_fast.release()
print(f"Fast motion video saved to: {fast_path}")

# Display/Play the speed-modified videos interactively
try:
    user_exit = False

    # 1. Play in Slow Motion
    print("Playing in Slow Motion... (Press 'q' to skip to Fast Motion, or close window to exit)")
    for frame in frames:
        cv2.imshow("Video Playback (Slow Motion)", frame)
        key = cv2.waitKey(100) & 0xFF
        if key == ord('q') or key == 27:
            break
        # If user closes the window, exit the whole script
        if cv2.getWindowProperty("Video Playback (Slow Motion)", cv2.WND_PROP_VISIBLE) < 1:
            user_exit = True
            break
    cv2.destroyAllWindows()

    # 2. Play in Fast Motion (only if user didn't close window during slow motion)
    if not user_exit:
        print("Playing in Fast Motion... (Press 'q' to exit, or close window to quit)")
        for i in range(0, len(frames), 2):
            cv2.imshow("Video Playback (Fast Motion)", frames[i])
            key = cv2.waitKey(15) & 0xFF
            if key == ord('q') or key == 27:
                break
            if cv2.getWindowProperty("Video Playback (Fast Motion)", cv2.WND_PROP_VISIBLE) < 1:
                break
        cv2.destroyAllWindows()
except Exception as e:
    print(f"Display playback skipped: {e}. Output videos saved successfully.")
