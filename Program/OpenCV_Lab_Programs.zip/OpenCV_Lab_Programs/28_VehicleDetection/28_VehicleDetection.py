import cv2
import os
import sys
import numpy as np

# Add root directory to python path for sample utility
current_dir = os.path.dirname(os.path.abspath(__file__))
root_dir = os.path.dirname(current_dir)
sys.path.append(root_dir)

# Ensure sample files exist
try:
    import sample_generator
    sample_generator.ensure_samples_exist(root_dir)
except Exception as e:
    print(f"Warning: Could not check or generate sample inputs: {e}")

# Read the sample input video
video_path = os.path.join(root_dir, "sample_video.mp4")
cap = cv2.VideoCapture(video_path)
if not cap.isOpened():
    print(f"Error: Could not open video from {video_path}")
    sys.exit(1)

# Get video properties
width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
fps = cap.get(cv2.CAP_PROP_FPS)
if fps <= 0:
    fps = 30.0

# Load Haar cascade for cars
cascade_path = os.path.join(root_dir, "cars.xml")
car_cascade = cv2.CascadeClassifier(cascade_path)

# Prepare video writer for output
output_video_path = os.path.join(current_dir, "output.mp4")
fourcc = cv2.VideoWriter_fourcc(*'mp4v')
out = cv2.VideoWriter(output_video_path, fourcc, fps, (width, height))

# Setup background subtractor for moving contour fallback
bg_subtractor = cv2.createBackgroundSubtractorMOG2(history=50, varThreshold=50, detectShadows=False)

frame_count = 0
processed_frames = []

while True:
    ret, frame = cap.read()
    if not ret:
        break
    
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    output_frame = frame.copy()
    
    # 1. Attempt Haar Cascade detection (for real car videos)
    cars = []
    if not car_cascade.empty():
        cars = car_cascade.detectMultiScale(gray, 1.1, 3, minSize=(30, 30))
        for (x, y, w, h) in cars:
            cv2.rectangle(output_frame, (x, y), (x + w, y + h), (0, 0, 255), 2)
            cv2.putText(output_frame, "Vehicle (Cascade)", (x, y - 5), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 1)

    # 2. Fallback to Contour-based motion tracking (for the synthetic moving ball simulation)
    # This detects movement which is standard in vehicle counting/tracking systems
    if len(cars) == 0:
        fg_mask = bg_subtractor.apply(frame)
        # Apply morphology to clean noise
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
        fg_mask = cv2.morphologyEx(fg_mask, cv2.MORPH_OPEN, kernel)
        
        # Find contours of moving objects
        contours, _ = cv2.findContours(fg_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        for contour in contours:
            if cv2.contourArea(contour) > 500: # Threshold area for vehicle sizes
                (x, y, w, h) = cv2.boundingRect(contour)
                # Avoid flagging the frame counter text
                if y < height - 60:
                    cv2.rectangle(output_frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
                    cv2.putText(output_frame, "Vehicle (Motion)", (x, y - 5), 
                                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)

    out.write(output_frame)
    processed_frames.append(output_frame)
    frame_count += 1

cap.release()
out.release()
print(f"Vehicle detection video saved to: {output_video_path} ({frame_count} frames processed)")

# Display the processed video
try:
    print("Playing processed vehicle detection video... (Press 'q' to exit)")
    for f in processed_frames:
        cv2.imshow("Vehicle Detection & Motion Tracking", f)
        if cv2.waitKey(33) & 0xFF == ord('q'):
            break
    cv2.destroyAllWindows()
except Exception as e:
    print(f"Display window skipped: {e}. Output video saved successfully.")
