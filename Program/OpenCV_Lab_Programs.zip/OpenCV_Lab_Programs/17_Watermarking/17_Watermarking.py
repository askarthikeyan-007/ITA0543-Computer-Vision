import cv2
import os
import sys

# Add root directory to python path for sample utility
current_dir = os.path.dirname(os.path.abspath(__file__))
root_dir = os.path.dirname(current_dir)
sys.path.append(root_dir)

# Ensure sample files exist
try:
    import sample_generator
    sample_generator.ensure_samples_exist(root_dir)
except Exception as e:
    print(f"Warning: Could not check or generate sample inputs: {e}")

# Read the sample input image
input_path = os.path.join(root_dir, "sample_input.jpg")
img = cv2.imread(input_path)
if img is None:
    print(f"Error: Could not read input image from {input_path}")
    sys.exit(1)

# Read the watermark image (reusing sample_watch.jpg as our watermark logo)
watermark_path = os.path.join(root_dir, "sample_watch.jpg")
watermark = cv2.imread(watermark_path)
if watermark is None:
    print(f"Error: Could not read watermark image from {watermark_path}")
    sys.exit(1)

# Get dimensions of base image and watermark
h_img, w_img, _ = img.shape
# Resize watermark to be a fraction of the original image size (e.g. 120x100)
watermark_w = 120
watermark_h = 100
watermark = cv2.resize(watermark, (watermark_w, watermark_h))

# Define ROI (Region of Interest) on the bottom-right corner of the base image
margin = 20
y_offset = h_img - watermark_h - margin
x_offset = w_img - watermark_w - margin
roi = img[y_offset:y_offset+watermark_h, x_offset:x_offset+watermark_w]

# Blend the ROI and watermark (alpha=0.7 for background, beta=0.3 for watermark)
blended = cv2.addWeighted(roi, 0.7, watermark, 0.3, 0)

# Replace the ROI in the original image with the blended image
output_img = img.copy()
output_img[y_offset:y_offset+watermark_h, x_offset:x_offset+watermark_w] = blended

# Add a text watermark as well for demonstration
cv2.putText(output_img, "Watermarked with OpenCV", (20, h_img - 20), 
            cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1, cv2.LINE_AA)

# Save the output image
output_path = os.path.join(current_dir, "output.jpg")
cv2.imwrite(output_path, output_img)
print(f"Watermarked image saved to: {output_path}")

# Display original and watermarked images
try:
    cv2.imshow("Original Image", img)
    cv2.imshow("Watermarked Image", output_img)
    print("Press 'q' or 'Esc' in any window to exit.")
    while True:
        key = cv2.waitKey(30) & 0xFF
        if key == ord('q') or key == 27:
            break
    cv2.destroyAllWindows()
except Exception as e:
    print(f"Display window skipped: {e}. Output saved to file successfully.")
