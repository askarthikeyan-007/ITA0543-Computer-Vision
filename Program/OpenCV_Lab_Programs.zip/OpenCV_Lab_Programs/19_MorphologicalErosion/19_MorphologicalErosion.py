import cv2
import numpy as np
import os
import sys

# Add root directory to python path for sample utility
current_dir = os.path.dirname(os.path.abspath(__file__))
root_dir = os.path.dirname(current_dir)
sys.path.append(root_dir)

# Ensure sample files exist
try:
    import sample_generator
    sample_generator.ensure_samples_exist(root_dir)
except Exception as e:
    print(f"Warning: Could not check or generate sample inputs: {e}")

# Read the sample input image
input_path = os.path.join(root_dir, "sample_input.jpg")
img = cv2.imread(input_path)
if img is None:
    print(f"Error: Could not read input image from {input_path}")
    sys.exit(1)

# Convert to grayscale and binary threshold
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
_, binary = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

# Define different structuring elements (kernels) of size 7x7
kernel_rect = cv2.getStructuringElement(cv2.MORPH_RECT, (7, 7))
kernel_ellipse = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (7, 7))
kernel_cross = cv2.getStructuringElement(cv2.MORPH_CROSS, (7, 7))

# Perform erosion with each kernel
eroded_rect = cv2.erode(binary, kernel_rect, iterations=1)
eroded_ellipse = cv2.erode(binary, kernel_ellipse, iterations=1)
eroded_cross = cv2.erode(binary, kernel_cross, iterations=1)

# Combine results side-by-side for comparison and save
# Since the images are binary (1 channel), we can stack them horizontally
comparison = np.hstack((binary, eroded_rect, eroded_ellipse, eroded_cross))
# Add label text to each quadrant
label_canvas = np.zeros((40, comparison.shape[1]), dtype=np.uint8)
cv2.putText(label_canvas, "Original Binary", (10, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.5, 255, 1)
cv2.putText(label_canvas, "Rect Kernel", (650, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.5, 255, 1)
cv2.putText(label_canvas, "Ellipse Kernel", (1290, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.5, 255, 1)
cv2.putText(label_canvas, "Cross Kernel", (1930, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.5, 255, 1)

final_output = np.vstack((comparison, label_canvas))

# Save output
output_path = os.path.join(current_dir, "output.jpg")
cv2.imwrite(output_path, final_output)
print(f"Morphological erosion comparison saved to: {output_path}")

# Display the comparison
try:
    cv2.imshow("Erosion Comparison (Original, Rect, Ellipse, Cross)", final_output)
    print("Press 'q' or 'Esc' in any window to exit.")
    while True:
        key = cv2.waitKey(30) & 0xFF
        if key == ord('q') or key == 27:
            break
    cv2.destroyAllWindows()
except Exception as e:
    print(f"Display window skipped: {e}. Output saved to file successfully.")
