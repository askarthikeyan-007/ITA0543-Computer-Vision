import cv2
import os
import sys

# Add root directory to python path for sample utility
current_dir = os.path.dirname(os.path.abspath(__file__))
root_dir = os.path.dirname(current_dir)
sys.path.append(root_dir)

# Ensure sample files exist
try:
    import sample_generator
    sample_generator.ensure_samples_exist(root_dir)
except Exception as e:
    print(f"Warning: Could not check or generate sample inputs: {e}")

# Read the sample input video
video_path = os.path.join(root_dir, "sample_video.mp4")
cap = cv2.VideoCapture(video_path)
if not cap.isOpened():
    print(f"Error: Could not open video from {video_path}")
    sys.exit(1)

# Get video properties
width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
fps = cap.get(cv2.CAP_PROP_FPS)
if fps <= 0:
    fps = 30.0

# Initialize the Background Subtractor MOG2
fgbg = cv2.createBackgroundSubtractorMOG2(history=500, varThreshold=16, detectShadows=True)

# Prepare VideoWriter to output the binary mask
# Since the mask is single-channel grayscale (0 to 255), we must write it as a 3-channel image 
# by repeating the channel or specifying isColor=True after converting.
output_video_path = os.path.join(current_dir, "output.mp4")
fourcc = cv2.VideoWriter_fourcc(*'mp4v')
out = cv2.VideoWriter(output_video_path, fourcc, fps, (width, height))

processed_frames = []
mask_frames = []

while True:
    ret, frame = cap.read()
    if not ret:
        break
    
    # Apply Background Subtraction to get the foreground mask
    fgmask = fgbg.apply(frame)
    
    # Convert single-channel mask to 3-channel to write to mp4
    fgmask_3ch = cv2.cvtColor(fgmask, cv2.COLOR_GRAY2BGR)
    out.write(fgmask_3ch)
    
    processed_frames.append(frame)
    mask_frames.append(fgmask)

cap.release()
out.release()
print(f"Background subtraction mask video saved to: {output_video_path}")

# Display original and background subtracted videos side-by-side
try:
    print("Playing side-by-side background subtraction... (Press 'q' to exit)")
    for i in range(len(processed_frames)):
        orig = processed_frames[i]
        mask = cv2.cvtColor(mask_frames[i], cv2.COLOR_GRAY2BGR)
        combined = cv2.hconcat([orig, mask])
        
        cv2.imshow("Original Frame vs Foreground Mask", combined)
        if cv2.waitKey(33) & 0xFF == ord('q'):
            break
    cv2.destroyAllWindows()
except Exception as e:
    print(f"Display window skipped: {e}. Output video saved successfully.")
