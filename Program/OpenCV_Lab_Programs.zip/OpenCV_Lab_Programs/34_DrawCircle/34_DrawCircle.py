import cv2
import numpy as np
import os
import sys

# Add root directory to python path for sample utility
current_dir = os.path.dirname(os.path.abspath(__file__))
root_dir = os.path.dirname(current_dir)
sys.path.append(root_dir)

# Ensure sample files exist
try:
    import sample_generator
    sample_generator.ensure_samples_exist(root_dir)
except Exception as e:
    print(f"Warning: Could not check or generate sample inputs: {e}")

# Read the sample input image
input_path = os.path.join(root_dir, "sample_input.jpg")
img = cv2.imread(input_path)
if img is None:
    print(f"Error: Could not read input image from {input_path}")
    sys.exit(1)

# Copy image for drawing
canvas = img.copy()

# 1. Draw static circles for demonstration
# Parameters: image, center, radius, color (BGR), thickness (-1 for filled)
cv2.circle(canvas, (100, 150), 50, (0, 0, 255), 3) # Outline Red
cv2.circle(canvas, (280, 150), 60, (0, 255, 0), -1) # Filled Green
cv2.circle(canvas, (460, 150), 40, (255, 255, 0), 4) # Yellow outline
cv2.putText(canvas, "Static Circles Demo", (30, 260), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)

# Save the pre-drawn static result
static_output_path = os.path.join(current_dir, "output.jpg")
cv2.imwrite(static_output_path, canvas)
print(f"Static circle image saved to: {static_output_path}")

# 2. Interactive Drag-to-Draw variables
drawing = False
ix, iy = -1, -1

# Mouse callback function
def draw_circle_callback(event, x, y, flags, param):
    global ix, iy, drawing, canvas

    if event == cv2.EVENT_LBUTTONDOWN:
        drawing = True
        ix, iy = x, y

    elif event == cv2.EVENT_MOUSEMOVE:
        if drawing:
            # Calculate dynamic radius based on distance from downclick point
            radius = int(np.sqrt((x - ix) ** 2 + (y - iy) ** 2))
            if radius > 0:
                temp_canvas = canvas.copy()
                cv2.circle(temp_canvas, (ix, iy), radius, (0, 255, 255), 2)
                cv2.imshow("Interactive Circle Drawing", temp_canvas)

    elif event == cv2.EVENT_LBUTTONUP:
        drawing = False
        radius = int(np.sqrt((x - ix) ** 2 + (y - iy) ** 2))
        if radius > 0:
            # Draw the permanent circle
            cv2.circle(canvas, (ix, iy), radius, (0, 255, 255), 2)
            cv2.imshow("Interactive Circle Drawing", canvas)
            # Save the updated drawing to disk
            cv2.imwrite(static_output_path, canvas)

# Run interactive window
try:
    cv2.namedWindow("Interactive Circle Drawing")
    cv2.setMouseCallback("Interactive Circle Drawing", draw_circle_callback)
    
    cv2.imshow("Interactive Circle Drawing", canvas)
    print("INSTRUCTIONS:")
    print("1. Click and drag the left mouse button inside the window to draw custom yellow circles.")
    print("2. The drawing will be saved to disk automatically upon button release.")
    print("3. Press 'q' or 'Esc' to exit.")
    
    while True:
        key = cv2.waitKey(30) & 0xFF
        if key == ord('q') or key == 27:
            break
            
    cv2.destroyAllWindows()
except Exception as e:
    print(f"Interactive window skipped: {e}. Pre-drawn static output saved successfully.")
