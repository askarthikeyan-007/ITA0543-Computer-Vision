import cv2
import os
import sys

# Add root directory to python path for sample utility
current_dir = os.path.dirname(os.path.abspath(__file__))
root_dir = os.path.dirname(current_dir)
sys.path.append(root_dir)

# Ensure sample files exist
try:
    import sample_generator
    sample_generator.ensure_samples_exist(root_dir)
except Exception as e:
    print(f"Warning: Could not check or generate sample inputs: {e}")

# Read the main sample image
input_path = os.path.join(root_dir, "sample_input.jpg")
img = cv2.imread(input_path)
if img is None:
    print(f"Error: Could not read input image from {input_path}")
    sys.exit(1)

# Read the template image (watch)
template_path = os.path.join(root_dir, "sample_watch.jpg")
template = cv2.imread(template_path)
if template is None:
    print(f"Error: Could not read template image from {template_path}")
    sys.exit(1)

# Perform Template Matching
res = cv2.matchTemplate(img, template, cv2.TM_CCOEFF_NORMED)
min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(res)

# Since TM_CCOEFF_NORMED is used, the maximum value is the best match location
top_left = max_loc
h, w, _ = template.shape
bottom_right = (top_left[0] + w, top_left[1] + h)

# Draw rectangle around the matched template area
output_img = img.copy()
cv2.rectangle(output_img, top_left, bottom_right, (0, 255, 0), 3)
cv2.putText(output_img, f"WATCH (Match: {max_val:.2f})", (top_left[0], top_left[1] - 10), 
            cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)

# Save the output image
output_path = os.path.join(current_dir, "output.jpg")
cv2.imwrite(output_path, output_img)
print(f"Template matching result saved to: {output_path} (Confidence: {max_val:.4f})")

# Display the result
try:
    cv2.imshow("Template Image (Watch)", template)
    cv2.imshow("Object Recognition Output", output_img)
    print("Press 'q' or 'Esc' in any window to exit.")
    while True:
        key = cv2.waitKey(30) & 0xFF
        if key == ord('q') or key == 27:
            break
    cv2.destroyAllWindows()
except Exception as e:
    print(f"Display window skipped: {e}. Output saved to file successfully.")
