import cv2
import os
import sys

# Add root directory to python path for sample utility
current_dir = os.path.dirname(os.path.abspath(__file__))
root_dir = os.path.dirname(current_dir)
sys.path.append(root_dir)

# Ensure sample files exist
try:
    import sample_generator
    sample_generator.ensure_samples_exist(root_dir)
except Exception as e:
    print(f"Warning: Could not check or generate sample inputs: {e}")

# Read the sample input image
input_path = os.path.join(root_dir, "sample_input.jpg")
img = cv2.imread(input_path)
if img is None:
    print(f"Error: Could not read input image from {input_path}")
    sys.exit(1)

# Rotate the image 180 degrees
rotated_img = cv2.rotate(img, cv2.ROTATE_180)

# Save the output image
output_path = os.path.join(current_dir, "output.jpg")
cv2.imwrite(output_path, rotated_img)
print(f"180-degree rotated image saved to: {output_path}")

# Display original and rotated images
try:
    cv2.imshow("Original Image", img)
    cv2.imshow("Rotated 180 Degrees", rotated_img)
    print("Press 'q' or 'Esc' in any window to exit.")
    while True:
        key = cv2.waitKey(30) & 0xFF
        if key == ord('q') or key == 27:
            break
    cv2.destroyAllWindows()
except Exception as e:
    print(f"Display window skipped: {e}. Output saved to file successfully.")
