import cv2
import numpy as np
import os
import sys

# Add root directory to python path for sample utility
current_dir = os.path.dirname(os.path.abspath(__file__))
root_dir = os.path.dirname(current_dir)
sys.path.append(root_dir)

# Ensure sample files exist
try:
    import sample_generator
    sample_generator.ensure_samples_exist(root_dir)
except Exception as e:
    print(f"Warning: Could not check or generate sample inputs: {e}")

# Read the sample input image
input_path = os.path.join(root_dir, "sample_input.jpg")
img = cv2.imread(input_path)
if img is None:
    print(f"Error: Could not read input image from {input_path}")
    sys.exit(1)

# Convert to grayscale and binary threshold (Otsu's thresholding)
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
_, binary = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

# Define structuring element (5x5 rectangular kernel)
kernel = np.ones((5, 5), np.uint8)

# Perform Erosion
eroded_img = cv2.erode(binary, kernel, iterations=1)

# Save the output image
output_path = os.path.join(current_dir, "output.jpg")
cv2.imwrite(output_path, eroded_img)
print(f"Eroded binary image saved to: {output_path}")

# Display binary and eroded images
try:
    cv2.imshow("Binary Thresholded Image", binary)
    cv2.imshow("Eroded Image", eroded_img)
    print("Press 'q' or 'Esc' in any window to exit, or close the windows to quit.")
    while True:
        key = cv2.waitKey(30) & 0xFF
        if key == ord('q') or key == 27:
            break
        # Check if any window was closed using the [X] button
        if cv2.getWindowProperty("Binary Thresholded Image", cv2.WND_PROP_VISIBLE) < 1 or \
           cv2.getWindowProperty("Eroded Image", cv2.WND_PROP_VISIBLE) < 1:
            break
    cv2.destroyAllWindows()
except Exception as e:
    print(f"Display window skipped: {e}. Output saved to file successfully.")
