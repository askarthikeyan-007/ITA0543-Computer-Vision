import cv2
import os
import sys

# Add root directory to python path for sample utility
current_dir = os.path.dirname(os.path.abspath(__file__))
root_dir = os.path.dirname(current_dir)
sys.path.append(root_dir)

# Ensure sample files exist
try:
    import sample_generator
    sample_generator.ensure_samples_exist(root_dir)
except Exception as e:
    print(f"Warning: Could not check or generate sample inputs: {e}")

# Read the sample input video
video_path = os.path.join(root_dir, "sample_video.mp4")
cap = cv2.VideoCapture(video_path)
if not cap.isOpened():
    print(f"Error: Could not open video from {video_path}")
    sys.exit(1)

# Get video properties
width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
fps = cap.get(cv2.CAP_PROP_FPS)
if fps <= 0:
    fps = 30.0

frames = []
while True:
    ret, frame = cap.read()
    if not ret:
        break
    frames.append(frame)
cap.release()

if len(frames) == 0:
    print("Error: No frames read from video.")
    sys.exit(1)

# Reverse the list of frames
reversed_frames = frames[::-1]

# Write reversed frames to a new video at half the original frame rate
output_video_path = os.path.join(current_dir, "output.mp4")
fourcc = cv2.VideoWriter_fourcc(*'mp4v')
# Writing at fps / 2 makes the video play in slow motion
out = cv2.VideoWriter(output_video_path, fourcc, fps / 2, (width, height))

for frame in reversed_frames:
    out.write(frame)
out.release()
print(f"Reversed, slow-motion video saved to: {output_video_path}")

# Interactively play the video in reversed slow-motion
try:
    print("Playing reversed slow-motion video... (Press 'q' to exit)")
    # Calculate delay in milliseconds: 1000 / (fps / 2)
    # E.g. for 30fps normal speed, half speed is 15fps, which is ~66ms delay.
    delay = int(2000 / fps)
    
    for frame in reversed_frames:
        cv2.imshow("Reversed Slow Motion Video Player", frame)
        if cv2.waitKey(delay) & 0xFF == ord('q'):
            break
    cv2.destroyAllWindows()
except Exception as e:
    print(f"Display playback skipped: {e}. Output video saved successfully.")
