import cv2
import numpy as np
import os
import sys

# Add root directory to python path for sample utility
current_dir = os.path.dirname(os.path.abspath(__file__))
root_dir = os.path.dirname(current_dir)
sys.path.append(root_dir)

# Ensure sample files exist
try:
    import sample_generator
    sample_generator.ensure_samples_exist(root_dir)
except Exception as e:
    print(f"Warning: Could not check or generate sample inputs: {e}")

# Read the sample input image
input_path = os.path.join(root_dir, "sample_input.jpg")
img = cv2.imread(input_path)
if img is None:
    print(f"Error: Could not read input image from {input_path}")
    sys.exit(1)

# Convert BGR to HSV color space
hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

# Define HSV range for Blue/Cyan objects
lower_blue = np.array([90, 50, 50])
upper_blue = np.array([130, 255, 255])
mask_blue = cv2.inRange(hsv, lower_blue, upper_blue)
res_blue = cv2.bitwise_and(img, img, mask=mask_blue)

# Define HSV range for Green objects
lower_green = np.array([35, 40, 40])
upper_green = np.array([85, 255, 255])
mask_green = cv2.inRange(hsv, lower_green, upper_green)
res_green = cv2.bitwise_and(img, img, mask=mask_green)

# Define HSV range for Red objects (Red wraps around 0 and 180 in Hue)
lower_red1 = np.array([0, 50, 50])
upper_red1 = np.array([10, 255, 255])
lower_red2 = np.array([170, 50, 50])
upper_red2 = np.array([180, 255, 255])
mask_red = cv2.inRange(hsv, lower_red1, upper_red1) + cv2.inRange(hsv, lower_red2, upper_red2)
res_red = cv2.bitwise_and(img, img, mask=mask_red)

# Draw label texts on the result images
def add_label(image, text):
    labeled = image.copy()
    cv2.putText(labeled, text, (15, 35), cv2.FONT_HERSHEY_SIMPLEX, 1.0, (255, 255, 255), 2)
    return labeled

img_labeled = add_label(img, "Original Image")
red_labeled = add_label(res_red, "Red Extracted")
green_labeled = add_label(res_green, "Green Extracted")
blue_labeled = add_label(res_blue, "Blue/Cyan Extracted")

# Combine results into a 2x2 grid
top_row = np.hstack((img_labeled, red_labeled))
bottom_row = np.hstack((green_labeled, blue_labeled))
grid = np.vstack((top_row, bottom_row))

# Save the grid image
output_path = os.path.join(current_dir, "output.jpg")
cv2.imwrite(output_path, grid)
print(f"Color boxes extraction grid saved to: {output_path}")

# Display the color-separated grid
try:
    cv2.imshow("Color Extraction (Original, Red, Green, Blue)", grid)
    print("Press 'q' or 'Esc' in any window to exit.")
    while True:
        key = cv2.waitKey(30) & 0xFF
        if key == ord('q') or key == 27:
            break
    cv2.destroyAllWindows()
except Exception as e:
    print(f"Display window skipped: {e}. Output saved to file successfully.")
