import cv2
import os
import sys

# Add root directory to python path for sample utility
current_dir = os.path.dirname(os.path.abspath(__file__))
root_dir = os.path.dirname(current_dir)
sys.path.append(root_dir)

# Ensure sample files exist
try:
    import sample_generator
    sample_generator.ensure_samples_exist(root_dir)
except Exception as e:
    print(f"Warning: Could not check or generate sample inputs: {e}")

# Read the sample input image
input_path = os.path.join(root_dir, "sample_input.jpg")
img = cv2.imread(input_path)
if img is None:
    print(f"Error: Could not read input image from {input_path}")
    sys.exit(1)

# Downscale the image by a factor of 0.5 using Area interpolation (best for shrinking)
downscaled = cv2.resize(img, (0, 0), fx=0.5, fy=0.5, interpolation=cv2.INTER_AREA)

# Upscale the image by a factor of 1.5 using Bicubic interpolation (best for zooming)
upscaled = cv2.resize(img, (0, 0), fx=1.5, fy=1.5, interpolation=cv2.INTER_CUBIC)

# Save the outputs
down_path = os.path.join(current_dir, "output_downscaled.jpg")
up_path = os.path.join(current_dir, "output_upscaled.jpg")
cv2.imwrite(down_path, downscaled)
cv2.imwrite(up_path, upscaled)
print(f"Downscaled image saved to: {down_path}")
print(f"Upscaled image saved to: {up_path}")

# Display scaled images
try:
    cv2.imshow("Original Image", img)
    cv2.imshow("Downscaled (0.5x)", downscaled)
    cv2.imshow("Upscaled (1.5x)", upscaled)
    print("Press 'q' or 'Esc' in any window to exit.")
    while True:
        key = cv2.waitKey(30) & 0xFF
        if key == ord('q') or key == 27:
            break
    cv2.destroyAllWindows()
except Exception as e:
    print(f"Display window skipped: {e}. Output images saved successfully.")
