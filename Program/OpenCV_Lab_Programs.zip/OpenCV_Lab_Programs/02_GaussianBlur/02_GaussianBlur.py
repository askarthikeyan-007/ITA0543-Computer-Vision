import cv2
import os
import sys

# Add root directory to python path for sample utility
current_dir = os.path.dirname(os.path.abspath(__file__))
root_dir = os.path.dirname(current_dir)
sys.path.append(root_dir)

# Ensure sample files exist
try:
    import sample_generator
    sample_generator.ensure_samples_exist(root_dir)
except Exception as e:
    print(f"Warning: Could not check or generate sample inputs: {e}")

# Read the sample input image
input_path = os.path.join(root_dir, "sample_input.jpg")
img = cv2.imread(input_path)
if img is None:
    print(f"Error: Could not read input image from {input_path}")
    sys.exit(1)

# Apply Gaussian Blur (kernel size 7x7, sigmaX=0 - auto calculated)
blurred_img = cv2.GaussianBlur(img, (7, 7), 0)

# Save the output image to current directory
output_path = os.path.join(current_dir, "output.jpg")
cv2.imwrite(output_path, blurred_img)
print(f"Gaussian blurred image saved to: {output_path}")

# Display original and blurred images
try:
    cv2.imshow("Original Image", img)
    cv2.imshow("Gaussian Blurred Image", blurred_img)
    print("Press 'q' or 'Esc' in any window to exit, or close the windows to quit.")
    while True:
        key = cv2.waitKey(30) & 0xFF
        if key == ord('q') or key == 27:
            break
        # Check if any window was closed using the [X] button
        if cv2.getWindowProperty("Original Image", cv2.WND_PROP_VISIBLE) < 1 or \
           cv2.getWindowProperty("Gaussian Blurred Image", cv2.WND_PROP_VISIBLE) < 1:
            break
    cv2.destroyAllWindows()
except Exception as e:
    print(f"Display window skipped: {e}. Output saved to file successfully.")
