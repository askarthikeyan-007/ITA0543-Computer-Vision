import cv2
import numpy as np
import os
import sys

# Add root directory to python path for sample utility
current_dir = os.path.dirname(os.path.abspath(__file__))
root_dir = os.path.dirname(current_dir)
sys.path.append(root_dir)

# Ensure sample files exist
try:
    import sample_generator
    sample_generator.ensure_samples_exist(root_dir)
except Exception as e:
    print(f"Warning: Could not check or generate sample inputs: {e}")

# Read the sample input image
input_path = os.path.join(root_dir, "sample_input.jpg")
img = cv2.imread(input_path)
if img is None:
    print(f"Error: Could not read input image from {input_path}")
    sys.exit(1)

# Define 4 source points (e.g., corners of the watch region in sample_input.jpg)
# Coordinates: Top-Left, Top-Right, Bottom-Left, Bottom-Right
pts1 = np.float32([[400, 280], [550, 280], [400, 400], [550, 400]])

# Define 4 corresponding destination points to warp into a square 300x300 image
pts2 = np.float32([[0, 0], [300, 0], [0, 300], [300, 300]])

# Get the perspective transformation matrix
matrix = cv2.getPerspectiveTransform(pts1, pts2)

# Warp the image using perspective transformation
warped_img = cv2.warpPerspective(img, matrix, (300, 300))

# Draw the point locations on the original image for visualization
visual_img = img.copy()
for pt in pts1:
    cv2.circle(visual_img, tuple(pt.astype(int)), 8, (0, 255, 0), -1)

# Save the output image
output_path = os.path.join(current_dir, "output.jpg")
cv2.imwrite(output_path, warped_img)
print(f"Perspective warped image saved to: {output_path}")

# Display original with marked points and the warped output
try:
    cv2.imshow("Original with Marked Points", visual_img)
    cv2.imshow("Perspective Warped (Watch Crop)", warped_img)
    print("Press 'q' or 'Esc' in any window to exit.")
    while True:
        key = cv2.waitKey(30) & 0xFF
        if key == ord('q') or key == 27:
            break
    cv2.destroyAllWindows()
except Exception as e:
    print(f"Display window skipped: {e}. Output saved to file successfully.")
