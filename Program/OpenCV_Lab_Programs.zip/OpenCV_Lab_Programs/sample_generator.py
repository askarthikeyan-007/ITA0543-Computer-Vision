import os
import urllib.request
import numpy as np
import cv2

def ensure_samples_exist(root_dir=None):
    if root_dir is None:
        root_dir = os.path.dirname(os.path.abspath(__file__))

    # 1. Generate sample_input.jpg
    input_path = os.path.join(root_dir, "sample_input.jpg")
    if not os.path.exists(input_path):
        print("Generating sample_input.jpg...")
        # Create a gradient background
        img = np.zeros((480, 640, 3), dtype=np.uint8)
        for y in range(480):
            color_val = int((y / 480.0) * 150)
            img[y, :, :] = [color_val + 50, color_val + 10, 30]

        # Draw a colorful grid
        for x in range(0, 640, 80):
            cv2.line(img, (x, 0), (x, 480), (100, 100, 100), 1)
        for y in range(0, 480, 60):
            cv2.line(img, (0, y), (640, y), (100, 100, 100), 1)

        # Draw some shape primitives
        cv2.circle(img, (150, 150), 60, (255, 100, 50), -1) # Blueish-cyan circle
        cv2.rectangle(img, (350, 80), (480, 200), (50, 50, 255), -1) # Red rectangle
        
        # Draw a polygon (triangle)
        pts = np.array([[100, 300], [200, 400], [50, 400]], np.int32)
        cv2.polylines(img, [pts], True, (50, 255, 255), 3)
        cv2.fillPoly(img, [pts], (50, 255, 100))

        # Text labels
        cv2.putText(img, "OpenCV Lab Input", (30, 60), cv2.FONT_HERSHEY_SIMPLEX, 1.2, (255, 255, 255), 3)

        # Draw a mock 'watch' pattern for template matching
        # Watch shape: a square containing a mini clock-face circle and text "WATCH"
        cv2.rectangle(img, (400, 280), (550, 400), (200, 200, 200), -1)
        cv2.rectangle(img, (400, 280), (550, 400), (0, 0, 0), 3)
        cv2.circle(img, (475, 330), 35, (80, 80, 80), 3)
        cv2.line(img, (475, 330), (475, 310), (0, 0, 255), 2) # Hour hand
        cv2.line(img, (475, 330), (495, 330), (0, 0, 255), 2) # Minute hand
        cv2.putText(img, "WATCH", (435, 390), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 0), 2)

        cv2.imwrite(input_path, img)
        print(f"Created: {input_path}")

    # 2. Generate sample_watch.jpg (Template for matching)
    watch_path = os.path.join(root_dir, "sample_watch.jpg")
    if not os.path.exists(watch_path):
        print("Generating sample_watch.jpg template...")
        img = cv2.imread(input_path)
        if img is not None:
            # Crop the watch region from (400, 280) to (550, 400)
            watch_template = img[280:400, 400:550]
            cv2.imwrite(watch_path, watch_template)
            print(f"Created: {watch_path}")

    # 3. Generate sample_video.mp4 (For video processing and speed adjustment)
    video_path = os.path.join(root_dir, "sample_video.mp4")
    if not os.path.exists(video_path):
        print("Generating sample_video.mp4...")
        width, height = 640, 480
        fourcc = cv2.VideoWriter_fourcc(*'mp4v')
        out = cv2.VideoWriter(video_path, fourcc, 30.0, (width, height))
        
        # Write 90 frames (3 seconds at 30 fps)
        for i in range(90):
            frame = np.zeros((height, width, 3), dtype=np.uint8)
            
            # Static background objects (to test background subtraction)
            cv2.rectangle(frame, (80, 80), (160, 160), (100, 100, 100), -1)
            cv2.putText(frame, "STATIC", (90, 130), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)

            # Moving object (a green ball bouncing around)
            x = int(50 + (i / 90.0) * 540)
            y = int(240 + np.sin(i * 0.15) * 100)
            
            cv2.circle(frame, (x, y), 30, (0, 255, 0), -1)
            cv2.putText(frame, "MOVING", (x - 30, y - 40), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)

            # Frame index text
            cv2.putText(frame, f"Frame: {i+1}/90", (20, 450), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1)
            
            out.write(frame)
        out.release()
        print(f"Created: {video_path}")

    # Helper function to download public domain test assets securely
    def download_url(url, dest_name):
        dest_path = os.path.join(root_dir, dest_name)
        if not os.path.exists(dest_path):
            print(f"Downloading {dest_name} from {url}...")
            try:
                urllib.request.urlretrieve(url, dest_path)
                print(f"Downloaded: {dest_path}")
            except Exception as e:
                print(f"Error downloading {dest_name}: {e}")

    # 4. Download sample_face.jpg (Lena) for Face/Eye/Smile detection
    download_url(
        "https://raw.githubusercontent.com/opencv/opencv/master/samples/data/lena.jpg",
        "sample_face.jpg"
    )

    # 5. Create sample_crowd.jpg programmatically by pasting multiple copies of sample_face.jpg
    crowd_path = os.path.join(root_dir, "sample_crowd.jpg")
    if not os.path.exists(crowd_path):
        print("Generating sample_crowd.jpg programmatically from sample_face.jpg...")
        face_img = cv2.imread(os.path.join(root_dir, "sample_face.jpg"))
        if face_img is not None:
            # Create a larger canvas
            canvas = np.zeros((300, 600, 3), dtype=np.uint8)
            # Resize face image to fit 3 times side-by-side
            resized = cv2.resize(face_img, (180, 180))
            # Paste them side by side
            canvas[60:240, 20:200] = resized
            canvas[60:240, 210:390] = resized
            canvas[60:240, 400:580] = resized
            cv2.imwrite(crowd_path, canvas)
            print(f"Created programmatically: {crowd_path}")
        else:
            print("Warning: could not load sample_face.jpg to generate sample_crowd.jpg")

    # 6. Download cars.xml for Vehicle Detection Cascade
    download_url(
        "https://raw.githubusercontent.com/andrewssobral/vehicle_detection_haarcascades/master/cars.xml",
        "cars.xml"
    )

if __name__ == "__main__":
    ensure_samples_exist()
