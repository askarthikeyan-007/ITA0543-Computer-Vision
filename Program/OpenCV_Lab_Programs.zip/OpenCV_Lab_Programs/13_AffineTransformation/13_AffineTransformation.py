import cv2
import numpy as np
import os
import sys

# Add root directory to python path for sample utility
current_dir = os.path.dirname(os.path.abspath(__file__))
root_dir = os.path.dirname(current_dir)
sys.path.append(root_dir)

# Ensure sample files exist
try:
    import sample_generator
    sample_generator.ensure_samples_exist(root_dir)
except Exception as e:
    print(f"Warning: Could not check or generate sample inputs: {e}")

# Read the sample input image
input_path = os.path.join(root_dir, "sample_input.jpg")
img = cv2.imread(input_path)
if img is None:
    print(f"Error: Could not read input image from {input_path}")
    sys.exit(1)

rows, cols, ch = img.shape

# Define 3 source points and their 3 corresponding destination points
pts1 = np.float32([[50, 50], [200, 50], [50, 200]])
pts2 = np.float32([[10, 100], [200, 50], [100, 250]])

# Get the affine transformation matrix
matrix = cv2.getAffineTransform(pts1, pts2)

# Warp the image using affine transformation
transformed_img = cv2.warpAffine(img, matrix, (cols, rows))

# Draw the point locations on the original image for visualization
visual_img = img.copy()
for pt in pts1:
    cv2.circle(visual_img, tuple(pt.astype(int)), 8, (0, 0, 255), -1)

# Save the output image
output_path = os.path.join(current_dir, "output.jpg")
cv2.imwrite(output_path, transformed_img)
print(f"Affine transformed image saved to: {output_path}")

# Display original (with marked points) and transformed images
try:
    cv2.imshow("Original with Marked Points", visual_img)
    cv2.imshow("Affine Transformed", transformed_img)
    print("Press 'q' or 'Esc' in any window to exit.")
    while True:
        key = cv2.waitKey(30) & 0xFF
        if key == ord('q') or key == 27:
            break
    cv2.destroyAllWindows()
except Exception as e:
    print(f"Display window skipped: {e}. Output saved to file successfully.")
