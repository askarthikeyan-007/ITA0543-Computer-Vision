import cv2
import numpy as np
import os
import sys

# Add root directory to python path for sample utility
current_dir = os.path.dirname(os.path.abspath(__file__))
root_dir = os.path.dirname(current_dir)
sys.path.append(root_dir)

# Ensure sample files exist
try:
    import sample_generator
    sample_generator.ensure_samples_exist(root_dir)
except Exception as e:
    print(f"Warning: Could not check or generate sample inputs: {e}")

# Read the sample input video
video_path = os.path.join(root_dir, "sample_video.mp4")
cap = cv2.VideoCapture(video_path)
if not cap.isOpened():
    print(f"Error: Could not open video from {video_path}")
    sys.exit(1)

# Get video properties
width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
fps = cap.get(cv2.CAP_PROP_FPS)
if fps <= 0:
    fps = 30.0

# Initialize the Background Subtractor MOG2
fgbg = cv2.createBackgroundSubtractorMOG2(history=500, varThreshold=16, detectShadows=True)

# Prepare VideoWriter for output
output_video_path = os.path.join(current_dir, "output.mp4")
fourcc = cv2.VideoWriter_fourcc(*'mp4v')
out = cv2.VideoWriter(output_video_path, fourcc, fps, (width, height))

processed_frames = []
extracted_frames = []

while True:
    ret, frame = cap.read()
    if not ret:
        break
    
    # 1. Apply background subtraction mask
    fgmask = fgbg.apply(frame)
    
    # 2. Clean mask with morphological opening and closing to remove speckles and shadows (shadows are label 127 in MOG2)
    _, cleaned_mask = cv2.threshold(fgmask, 200, 255, cv2.THRESH_BINARY)
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
    cleaned_mask = cv2.morphologyEx(cleaned_mask, cv2.MORPH_OPEN, kernel)
    cleaned_mask = cv2.morphologyEx(cleaned_mask, cv2.MORPH_CLOSE, kernel)
    
    # 3. Apply mask to extract the full color moving object
    fg_color = cv2.bitwise_and(frame, frame, mask=cleaned_mask)
    
    # Write the extracted colored foreground frame to output
    out.write(fg_color)
    
    processed_frames.append(frame)
    extracted_frames.append(fg_color)

cap.release()
out.release()
print(f"Foreground extraction video successfully saved to: {output_video_path}")

# Display side-by-side video playback
try:
    print("Playing side-by-side foreground extraction... (Press 'q' to exit)")
    for i in range(len(processed_frames)):
        orig = processed_frames[i]
        fg = extracted_frames[i]
        combined = cv2.hconcat([orig, fg])
        
        cv2.imshow("Original vs Extracted Foreground (Color)", combined)
        if cv2.waitKey(33) & 0xFF == ord('q'):
            break
    cv2.destroyAllWindows()
except Exception as e:
    print(f"Display window skipped: {e}. Output video saved successfully.")
