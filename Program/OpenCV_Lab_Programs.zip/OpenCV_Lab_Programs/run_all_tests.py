import os
import sys
import subprocess
import time

# Configuration
python_exe = r"C:\Users\A Karthikeyan\AppData\Local\Programs\Python\Python313\python.exe"
root_dir = os.path.dirname(os.path.abspath(__file__))

# Map directory name to expected output file(s) relative to the subdirectory
output_mapping = {
    "01_GrayScale": ["output.jpg"],
    "02_GaussianBlur": ["output.jpg"],
    "03_CannyEdge": ["output.jpg"],
    "04_HistogramEqualization": ["output.jpg"],
    "05_HistogramAnalysis": ["histogram_plot.png"],
    "06_Erosion": ["output.jpg"],
    "07_VideoSlowFastMotion": ["output_slow.mp4", "output_fast.mp4"],
    "08_Dilation": ["output.jpg"],
    "09_ImageScaling": ["output_downscaled.jpg", "output_upscaled.jpg"],
    "10_Rotate90": ["output.jpg"],
    "11_Rotate180": ["output.jpg"],
    "12_Rotate270": ["output.jpg"],
    "13_AffineTransformation": ["output.jpg"],
    "14_PerspectiveTransformation": ["output.jpg"],
    "15_HarrisCornerDetection": ["output.jpg"],
    "16_SobelFilter": ["output.jpg"],
    "17_Watermarking": ["output.jpg"],
    "18_ROI_CropCopyPaste": ["output.jpg"],
    "19_MorphologicalErosion": ["output.jpg"],
    "20_MorphologicalDilation": ["output.jpg"],
    "21_MorphologicalOpening": ["output.jpg"],
    "22_MorphologicalClosing": ["output.jpg"],
    "23_TopHat": ["output.jpg"],
    "24_BlackHat": ["output.jpg"],
    "25_ObjectRecognitionWatch": ["output.jpg"],
    "26_ReverseVideo": ["output.mp4"],
    "27_FaceDetection": ["output.jpg"],
    "28_VehicleDetection": ["output.mp4"],
    "29_EyeDetection": ["output.jpg"],
    "30_SmileDetection": ["output.jpg"],
    "31_ImageSegmentation": ["output.jpg"],
    "32_ColorBoxesImage": ["output.jpg"],
    "33_DrawRectangle": ["output.jpg"],
    "34_DrawCircle": ["output.jpg"],
    "35_DisplayText": ["output.jpg"],
    "36_BackgroundSubtraction": ["output.mp4"],
    "37_ForegroundSubtraction": ["output.mp4"],
    "38_CountFaces": ["output.jpg"],
    "39_ReverseSlowMotionVideo": ["output.mp4"],
    "40_TextExtractionFromVideo": ["output.mp4"]
}

def run_test(subdir):
    script_dir = os.path.join(root_dir, subdir)
    script_name = f"{subdir}.py"
    script_path = os.path.join(script_dir, script_name)
    
    if not os.path.exists(script_path):
        return False, "Script file does not exist"

    # Resolve expected outputs
    expected_files = output_mapping.get(subdir, [])
    if not expected_files:
        return False, "No expected outputs configured"

    # Delete any existing expected outputs to avoid false positives
    for f in expected_files:
        f_path = os.path.join(script_dir, f)
        if os.path.exists(f_path):
            try:
                os.remove(f_path)
            except Exception as e:
                return False, f"Could not remove stale output file {f}: {e}"

    # Start the script in a subprocess
    # Run with stdout/stderr piped so we can analyze errors if it crashes early
    proc = subprocess.Popen(
        [python_exe, script_path],
        cwd=script_dir,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True
    )

    # Give the script 2.5 seconds to run (enough to write output.jpg, but terminates before blocking)
    time.sleep(2.5)

    # Check if process is still running; if so, terminate it
    is_terminated = False
    if proc.poll() is None:
        proc.terminate()
        is_terminated = True
        # Wait a brief moment to ensure cleanup
        try:
            proc.wait(timeout=1.0)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait()

    # If it terminated on its own, it might have failed/crashed
    if not is_terminated:
        stdout, stderr = proc.communicate()
        if proc.returncode != 0:
            return False, f"Crashed early (Exit Code {proc.returncode}). Error:\n{stderr}"

    # Check if the expected output files were successfully created
    missing_files = []
    for f in expected_files:
        f_path = os.path.join(script_dir, f)
        if not os.path.exists(f_path) or os.path.getsize(f_path) == 0:
            missing_files.append(f)

    if missing_files:
        return False, f"Missing or empty output files: {', '.join(missing_files)}"

    return True, "Passed"

def main():
    print("=" * 60)
    print("OpenCV Lab Programs Automated Test Runner")
    print("=" * 60)
    print(f"Python: {python_exe}")
    print(f"Workspace: {root_dir}\n")

    # Filter directory list to lab exercises only
    subdirs = sorted([d for d in os.listdir(root_dir) if os.path.isdir(os.path.join(root_dir, d)) and d[0].isdigit()])

    passed_count = 0
    failed_count = 0
    failures = []

    for idx, subdir in enumerate(subdirs):
        print(f"[{idx+1}/{len(subdirs)}] Testing {subdir}... ", end="", flush=True)
        success, message = run_test(subdir)
        if success:
            print("PASSED")
            passed_count += 1
        else:
            print("FAILED")
            print(f"  Reason: {message}")
            failed_count += 1
            failures.append((subdir, message))

    print("\n" + "=" * 60)
    print("Test Session Summary")
    print("=" * 60)
    print(f"Total Programs Tested: {len(subdirs)}")
    print(f"Passed: {passed_count}")
    print(f"Failed: {failed_count}")
    print("=" * 60)

    if failures:
        print("\nFailures:")
        for name, msg in failures:
            print(f"- {name}: {msg}")
        sys.exit(1)
    else:
        print("\nAll 40 OpenCV lab programs verified successfully!")
        sys.exit(0)

if __name__ == "__main__":
    main()
