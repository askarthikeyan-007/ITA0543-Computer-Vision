import cv2
import numpy as np
import os
import sys

# Add root directory to python path for sample utility
current_dir = os.path.dirname(os.path.abspath(__file__))
root_dir = os.path.dirname(current_dir)
sys.path.append(root_dir)

# Ensure sample files exist
try:
    import sample_generator
    sample_generator.ensure_samples_exist(root_dir)
except Exception as e:
    print(f"Warning: Could not check or generate sample inputs: {e}")

# Read the sample input image
input_path = os.path.join(root_dir, "sample_input.jpg")
img = cv2.imread(input_path)
if img is None:
    print(f"Error: Could not read input image from {input_path}")
    sys.exit(1)

# Convert to grayscale and binary threshold
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
_, binary = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

# Add synthetic noise (white noise dots in the background)
noisy_binary = binary.copy()
h, w = noisy_binary.shape
noise_density = 0.02 # 2% pixels
num_noise_pixels = int(noise_density * h * w)
for _ in range(num_noise_pixels):
    y_rand = np.random.randint(0, h)
    x_rand = np.random.randint(0, w)
    noisy_binary[y_rand, x_rand] = 255

# Define structuring element (5x5 rectangular kernel)
kernel = np.ones((5, 5), np.uint8)

# Perform Morphological Opening (removes white noise in background)
opened_img = cv2.morphologyEx(noisy_binary, cv2.MORPH_OPEN, kernel)

# Save the output image
output_path = os.path.join(current_dir, "output.jpg")
cv2.imwrite(output_path, opened_img)
print(f"Opened binary image saved to: {output_path}")

# Display noisy binary and cleaned images
try:
    cv2.imshow("Noisy Binary Image (Noise Added)", noisy_binary)
    cv2.imshow("Morphological Opening (Noise Removed)", opened_img)
    print("Press 'q' or 'Esc' in any window to exit.")
    while True:
        key = cv2.waitKey(30) & 0xFF
        if key == ord('q') or key == 27:
            break
    cv2.destroyAllWindows()
except Exception as e:
    print(f"Display window skipped: {e}. Output saved to file successfully.")
