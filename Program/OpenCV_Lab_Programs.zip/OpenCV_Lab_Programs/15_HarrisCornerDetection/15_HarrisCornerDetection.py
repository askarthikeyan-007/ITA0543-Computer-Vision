import cv2
import numpy as np
import os
import sys

# Add root directory to python path for sample utility
current_dir = os.path.dirname(os.path.abspath(__file__))
root_dir = os.path.dirname(current_dir)
sys.path.append(root_dir)

# Ensure sample files exist
try:
    import sample_generator
    sample_generator.ensure_samples_exist(root_dir)
except Exception as e:
    print(f"Warning: Could not check or generate sample inputs: {e}")

# Read the sample input image
input_path = os.path.join(root_dir, "sample_input.jpg")
img = cv2.imread(input_path)
if img is None:
    print(f"Error: Could not read input image from {input_path}")
    sys.exit(1)

# Convert to grayscale and float32
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
gray_f32 = np.float32(gray)

# Apply Harris Corner Detection
# parameters: img, block size (size of neighborhood), ksize (aperture parameter for Sobel), k (Harris detector free parameter)
dst = cv2.cornerHarris(gray_f32, 2, 3, 0.04)

# Dilate the corner points to make them more prominent
dst = cv2.dilate(dst, None)

# Threshold to mark the corners on the original image in red
output_img = img.copy()
output_img[dst > 0.01 * dst.max()] = [0, 0, 255]

# Save the output image
output_path = os.path.join(current_dir, "output.jpg")
cv2.imwrite(output_path, output_img)
print(f"Harris corner image saved to: {output_path}")

# Display original and corner detected images
try:
    cv2.imshow("Original Image", img)
    cv2.imshow("Harris Corners (Red)", output_img)
    print("Press 'q' or 'Esc' in any window to exit.")
    while True:
        key = cv2.waitKey(30) & 0xFF
        if key == ord('q') or key == 27:
            break
    cv2.destroyAllWindows()
except Exception as e:
    print(f"Display window skipped: {e}. Output saved to file successfully.")
