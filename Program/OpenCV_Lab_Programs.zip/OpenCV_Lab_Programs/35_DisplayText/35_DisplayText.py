import cv2
import numpy as np
import os
import sys

# Add root directory to python path for sample utility
current_dir = os.path.dirname(os.path.abspath(__file__))
root_dir = os.path.dirname(current_dir)
sys.path.append(root_dir)

# Ensure sample files exist
try:
    import sample_generator
    sample_generator.ensure_samples_exist(root_dir)
except Exception as e:
    print(f"Warning: Could not check or generate sample inputs: {e}")

# Create a clean dark canvas to show off the font faces clearly
canvas = np.zeros((600, 800, 3), dtype=np.uint8)
# Add a soft dark grey gradient
for y in range(600):
    canvas[y, :, :] = [int(20 + (y / 600.0) * 30)] * 3

# Define fonts and labels
fonts_demo = [
    ("SIMPLEX: standard sans-serif", cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 1),
    ("PLAIN: simple small sans-serif", cv2.FONT_HERSHEY_PLAIN, 1.2, (0, 255, 255), 1),
    ("DUPLEX: 2-line sans-serif", cv2.FONT_HERSHEY_DUPLEX, 0.8, (0, 255, 0), 1),
    ("COMPLEX: complex serif font", cv2.FONT_HERSHEY_COMPLEX, 0.8, (255, 0, 255), 1),
    ("TRIPLEX: 3-line serif font", cv2.FONT_HERSHEY_TRIPLEX, 0.9, (0, 128, 255), 2),
    ("SCRIPT SIMPLEX: handwriting-like", cv2.FONT_HERSHEY_SCRIPT_SIMPLEX, 0.9, (255, 255, 0), 1),
    ("SCRIPT COMPLEX: ornate handwriting", cv2.FONT_HERSHEY_SCRIPT_COMPLEX, 1.0, (255, 0, 128), 1),
    ("ITALIC OVERLAY COMBINATION", cv2.FONT_HERSHEY_SIMPLEX | cv2.FONT_ITALIC, 0.8, (0, 255, 255), 2)
]

# Draw header
cv2.putText(canvas, "OpenCV Text Display Fonts", (40, 50), cv2.FONT_HERSHEY_TRIPLEX, 1.2, (255, 255, 255), 2, cv2.LINE_AA)
cv2.line(canvas, (40, 70), (740, 70), (100, 100, 100), 2)

# Write each font sample onto the canvas
start_y = 120
for label, font_face, scale, color, thickness in fonts_demo:
    # Render shadow first
    cv2.putText(canvas, label, (42, start_y + 2), font_face, scale, (0, 0, 0), thickness + 1, cv2.LINE_AA)
    # Render text
    cv2.putText(canvas, label, (40, start_y), font_face, scale, color, thickness, cv2.LINE_AA)
    start_y += 55

# Save the text overlay image
output_path = os.path.join(current_dir, "output.jpg")
cv2.imwrite(output_path, canvas)
print(f"Text display image saved to: {output_path}")

# Display result
try:
    cv2.imshow("OpenCV Text Rendering Styles", canvas)
    print("Press 'q' or 'Esc' in any window to exit.")
    while True:
        key = cv2.waitKey(30) & 0xFF
        if key == ord('q') or key == 27:
            break
    cv2.destroyAllWindows()
except Exception as e:
    print(f"Display window skipped: {e}. Output saved to file successfully.")
