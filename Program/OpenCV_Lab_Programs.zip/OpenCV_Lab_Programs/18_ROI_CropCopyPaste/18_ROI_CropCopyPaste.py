import cv2
import os
import sys

# Add root directory to python path for sample utility
current_dir = os.path.dirname(os.path.abspath(__file__))
root_dir = os.path.dirname(current_dir)
sys.path.append(root_dir)

# Ensure sample files exist
try:
    import sample_generator
    sample_generator.ensure_samples_exist(root_dir)
except Exception as e:
    print(f"Warning: Could not check or generate sample inputs: {e}")

# Read the sample input image
input_path = os.path.join(root_dir, "sample_input.jpg")
img = cv2.imread(input_path)
if img is None:
    print(f"Error: Could not read input image from {input_path}")
    sys.exit(1)

output_img = img.copy()

# Crop the circle region from sample_input.jpg (centered around (150, 150), radius 60)
# Region: y from 90 to 210, x from 90 to 210
roi = img[90:210, 90:210]

# Define pasting coordinates (bottom-left region: y from 300 to 420, x from 50 to 170)
# Ensure the dimensions match the cropped ROI exactly (120x120 pixels)
output_img[300:420, 50:170] = roi

# Draw rectangle outline indicating source crop and destination paste regions
visual_img = img.copy()
cv2.rectangle(visual_img, (90, 90), (210, 210), (0, 255, 255), 2) # Yellow source box
cv2.putText(visual_img, "Source ROI", (90, 85), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255), 1)

# Highlight destination paste region on output
cv2.rectangle(output_img, (50, 300), (170, 420), (0, 255, 0), 2) # Green destination box
cv2.putText(output_img, "Pasted ROI", (50, 295), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)

# Save the output image
output_path = os.path.join(current_dir, "output.jpg")
cv2.imwrite(output_path, output_img)
print(f"ROI copied and pasted image saved to: {output_path}")

# Display original with marked source and the final pasted result
try:
    cv2.imshow("Original with Source ROI Marked", visual_img)
    cv2.imshow("Result with Copied/Pasted ROI", output_img)
    print("Press 'q' or 'Esc' in any window to exit.")
    while True:
        key = cv2.waitKey(30) & 0xFF
        if key == ord('q') or key == 27:
            break
    cv2.destroyAllWindows()
except Exception as e:
    print(f"Display window skipped: {e}. Output saved to file successfully.")
