import cv2
import os
import sys

# Add root directory to python path for sample utility
current_dir = os.path.dirname(os.path.abspath(__file__))
root_dir = os.path.dirname(current_dir)
sys.path.append(root_dir)

# Ensure sample files exist
try:
    import sample_generator
    sample_generator.ensure_samples_exist(root_dir)
except Exception as e:
    print(f"Warning: Could not check or generate sample inputs: {e}")

# Read the sample face image (Lena)
input_path = os.path.join(root_dir, "sample_face.jpg")
img = cv2.imread(input_path)
if img is None:
    print(f"Error: Could not read input image from {input_path}")
    sys.exit(1)

# Load face and smile cascades
face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
smile_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_smile.xml')

if face_cascade.empty() or smile_cascade.empty():
    print("Error: Could not load Haar Cascade XML files.")
    sys.exit(1)

# Convert to grayscale
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

# Detect faces
faces = face_cascade.detectMultiScale(gray, 1.3, 5)

output_img = img.copy()

for (x, y, w, h) in faces:
    # Draw face boundary
    cv2.rectangle(output_img, (x, y), (x + w, y + h), (255, 0, 0), 2)
    cv2.putText(output_img, "Face", (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 0, 0), 2)

    # ROI for the face (smile search is restricted to the lower part of the face to avoid false positives)
    # y ranges from y + half of height to y + height
    roi_gray = gray[y + int(h * 0.5):y + h, x:x + w]
    roi_color = output_img[y + int(h * 0.5):y + h, x:x + w]

    # Detect smiles inside the lower face ROI
    # We use a relatively high minNeighbors (e.g. 20-30) and scaleFactor (e.g. 1.7) to restrict false positives
    smiles = smile_cascade.detectMultiScale(roi_gray, scaleFactor=1.7, minNeighbors=22, minSize=(25, 25))
    
    for (sx, sy, sw, sh) in smiles:
        # Draw green bounding box around smile
        cv2.rectangle(roi_color, (sx, sy), (sx + sw, sy + sh), (0, 255, 0), 2)
        cv2.putText(roi_color, "Smile", (sx, sy - 5), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)

print(f"Detected {len(faces)} face(s) and checked for smiles.")

# Save the output image
output_path = os.path.join(current_dir, "output.jpg")
cv2.imwrite(output_path, output_img)
print(f"Smile detection result saved to: {output_path}")

# Display original and smile detected images
try:
    cv2.imshow("Original Image", img)
    cv2.imshow("Detected Smile", output_img)
    print("Press 'q' or 'Esc' in any window to exit.")
    while True:
        key = cv2.waitKey(30) & 0xFF
        if key == ord('q') or key == 27:
            break
    cv2.destroyAllWindows()
except Exception as e:
    print(f"Display window skipped: {e}. Output saved to file successfully.")
