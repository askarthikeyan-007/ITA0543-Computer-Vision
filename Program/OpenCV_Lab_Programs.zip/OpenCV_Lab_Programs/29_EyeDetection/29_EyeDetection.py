import cv2
import os
import sys

# Add root directory to python path for sample utility
current_dir = os.path.dirname(os.path.abspath(__file__))
root_dir = os.path.dirname(current_dir)
sys.path.append(root_dir)

# Ensure sample files exist
try:
    import sample_generator
    sample_generator.ensure_samples_exist(root_dir)
except Exception as e:
    print(f"Warning: Could not check or generate sample inputs: {e}")

# Read the sample face image (Lena)
input_path = os.path.join(root_dir, "sample_face.jpg")
img = cv2.imread(input_path)
if img is None:
    print(f"Error: Could not read input image from {input_path}")
    sys.exit(1)

# Load face and eye cascade classifiers
face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
eye_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_eye.xml')

if face_cascade.empty() or eye_cascade.empty():
    print("Error: Could not load Haar Cascade XML files.")
    sys.exit(1)

# Convert to grayscale
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

# First detect faces
faces = face_cascade.detectMultiScale(gray, 1.3, 5)

output_img = img.copy()

for (x, y, w, h) in faces:
    # Draw face boundary
    cv2.rectangle(output_img, (x, y), (x + w, y + h), (255, 0, 0), 2)
    cv2.putText(output_img, "Face", (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 0, 0), 2)

    # ROI for face region
    roi_gray = gray[y:y+h, x:x+w]
    roi_color = output_img[y:y+h, x:x+w]

    # Detect eyes within the face ROI
    eyes = eye_cascade.detectMultiScale(roi_gray, scaleFactor=1.1, minNeighbors=10, minSize=(15, 15))
    
    for (ex, ey, ew, eh) in eyes:
        # Draw circles around eyes (in the face coordinate space)
        center = (ex + ew // 2, ey + eh // 2)
        radius = int(round((ew + eh) * 0.25))
        cv2.circle(roi_color, center, radius, (0, 255, 0), 2)
        cv2.putText(roi_color, "Eye", (ex, ey - 5), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 255, 0), 1)

print(f"Detected {len(faces)} face(s) and marked eyes.")

# Save the output image
output_path = os.path.join(current_dir, "output.jpg")
cv2.imwrite(output_path, output_img)
print(f"Eye detection result saved to: {output_path}")

# Display original and eye detected images
try:
    cv2.imshow("Original Image", img)
    cv2.imshow("Detected Eyes", output_img)
    print("Press 'q' or 'Esc' in any window to exit.")
    while True:
        key = cv2.waitKey(30) & 0xFF
        if key == ord('q') or key == 27:
            break
    cv2.destroyAllWindows()
except Exception as e:
    print(f"Display window skipped: {e}. Output saved to file successfully.")
